
package com.android.allinoneapp.api.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Friend {
    public Integer id;
    public String name;
}